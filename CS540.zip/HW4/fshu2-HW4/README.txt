William Shu
9073748874
Partner: Zhiqian Ma
I will hand in the coding part.

p.s. hand in late due to Easter