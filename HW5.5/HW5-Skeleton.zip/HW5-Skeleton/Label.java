/**
 * An enumeration representing the three classes of interest.
 * 
 * DO NOT MODIFY
 */
public enum Label {
    COMEDY, HISTORY, TRAGEDY
}
